import { GoogleGenAI } from "@google/genai";
import { StrategyParameters } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const getStrategyAnalysis = async (params: StrategyParameters): Promise<string> => {
    const model = 'gemini-2.5-flash';

    const recurringInvestmentDetails = params.enableRecurringInvestment
        ? `此外，啟用了一個定期定額策略：
            - 每月額外投入 ${params.monthlyInvestmentTWD.toLocaleString()} 新台幣。
            - 當累積的儲蓄足夠以 1:${params.exchangeRate} 的匯率兌換並購買 100 股 TQQQ 時，資金將被投入到主策略中。`
        : ``;

    const cashTacticDetails = params.enableCashTactic 
        ? `回測包含了兩種進階策略，保留了 ${params.cashReservePercentage}% 的初始資金用於逢低買入。
        - 剩餘的 ${100 - params.cashReservePercentage}% 資金用於主要策略（選擇權輪動或買入持有）。
        - 現金儲備根據以下觸發條件（從歷史高點下跌的百分比）進行部署：
            - 觸發點 1: 下跌 ${params.dipTriggers[0].drop}%, 使用 ${params.dipTriggers[0].use}% 的儲備金。
            - 觸發點 2: 下跌 ${params.dipTriggers[1].drop}%, 使用 ${params.dipTriggers[1].use}% 的儲備金。
            - 觸發點 3: 下跌 ${params.dipTriggers[2].drop}%, 使用 ${params.dipTriggers[2].use}% 的儲備金。`
        : `回測比較了標準的選擇權輪動策略與標準的買入持有策略，兩者都從第一天起就使用 100% 的初始資金。`;

    const prompt = `
        請分析以下 TQQQ 回測，此回測比較了四種不同的策略。請以繁體中文、Markdown 格式提供一份簡潔的摘要，重點關注每種方法的潛在風險和回報。

        四種策略分別是：
        1.  **純選擇權輪動 (Pure Options Wheel)**：100% 資金用於標準的賣出賣權（Sell Put）／賣出買權（Sell Call）輪動策略。
        2.  **純買入持有 (Pure Buy & Hold)**：100% 資金從開始日期就用於買入並持有 TQQQ。
        3.  **選擇權輪動 + 現金儲備 (Options Wheel + Cash Reserve)**：僅使用 ${100 - params.cashReservePercentage}% 的資金執行選擇權輪動策略，同時保留 ${params.cashReservePercentage}% 的現金，用於在 TQQQ 大幅下跌時買入。
        4.  **買入持有 + 現金儲備 (Buy & Hold + Cash Reserve)**：僅使用 ${100 - params.cashReservePercentage}% 的資金執行買入持有策略，同時保留 ${params.cashReservePercentage}% 的現金，用於在 TQQQ 大幅下跌時買入。

        關鍵參數：
        - 時間區間：${params.startDate} 到 ${params.endDate}
        - 初始資金：${params.initialCapital.toLocaleString()} TWD (以 1:${params.exchangeRate} 匯率兌換為美金)
        - 選擇權 DTE（到期天數）：${params.putDTE} (Put), ${params.callDTE} (Call)
        - Put Delta：${params.putDelta}
        - Call Delta：${params.callDelta}
        
        ${recurringInvestmentDetails}

        ${cashTacticDetails}

        請分析以下幾點：
        - 「純粹」100% 投入的策略與「現金儲備」策略在風險／回報上的根本差異。
        - 持有現金儲備的有效性如何根據所選時間段內的市場狀況（例如，牛市對比大崩盤）而改變。
        - 對於輪動策略的嚴格規則——只有當股價高於原始履約價時才賣出買權（Covered Call）——所帶來的影響。
        - 定期定額策略在長期累積資產和分散時間風險上的潛在影響。
        
        **重要：請務必使用繁體中文回答。**
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error getting strategy analysis from Gemini:", error);
        return "無法從 AI 獲取分析。請檢查您的 API 金鑰和網路連線。";
    }
};